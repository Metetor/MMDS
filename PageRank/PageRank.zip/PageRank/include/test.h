#ifndef __TEST_H__
#define __TEST_H__
#include"PageRank.h"
void test_load_data();
void test_weight_update();
//void test_BS_weight_update();
void test_read_dat(string fname);
void dat2txt(string dat, string txt);
#endif // !__TEST_H__
